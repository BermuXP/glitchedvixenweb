<?php include_once('./header.html'); ?>

<div class='container'>
    <div class='top-div'>
        <h1 class='header'>GlitchedVixen is a <s>bully</s> VERY NICE CAT!</h1>
        <h1 class='sub-header'>So check out: </h1>
        <div class='button-row'>
            <a class='button twitch' href='https://www.twitch.tv/glitchedvixen'>Twitch</a>
            <h2>&</h2>
            <a class='button kick' href='https://kick.com/glitchedvixen'>Kick</a>
            <p class='small'>Please follow.. or she'll rip my heart out.</p>
        </div>
    </div>
    <a href='https://glitchedvixen.com/betrayal/' class="extra-display-banner left-banner">
        <img src="./public/img/hot_vixens_in_your_area.png" alt="Left extra-display">
        <span class="extra-display-text">Click For Hot Vixens In Your Area</span>
    </a>
    <a href='https://kick.com/glitchedvixen' class="extra-display-banner right-banner">
        <img src="./public/img/hot_vixens_in_your_area.png" alt="Right extra-displayd">
        <span class="extra-display-text">Click For Hot Vixens In Your Area</span>
    </a>
    <a href='https://twitch.com/glitchedvixen' class="bottom-banner">
        <img src="./public/img/tail.png" alt="Bottom Content">
        <span class="extra-display-text">Tiny Tail? Click Here To Find Out How To Enlarge Your Tail</span>
    </a>
</div>
<script type='text/javascript' src='./public/js/glitched-main.js'></script>
<?php include_once('./footer.html'); ?>

